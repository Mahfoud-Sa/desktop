﻿namespace سطح_المكتب
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label_time = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.name_notepad = new System.Windows.Forms.Label();
            this.NOTEpad = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.chrome = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.power = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.Log_out = new System.Windows.Forms.Button();
            this.Sleep = new System.Windows.Forms.Button();
            this.Rstart = new System.Windows.Forms.Button();
            this.P_OFF = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.button12 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_time
            // 
            this.label_time.AutoSize = true;
            this.label_time.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_time.Location = new System.Drawing.Point(48, 14);
            this.label_time.Name = "label_time";
            this.label_time.Size = new System.Drawing.Size(29, 12);
            this.label_time.TabIndex = 0;
            this.label_time.Text = "lable";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.button29);
            this.panel1.Controls.Add(this.button28);
            this.panel1.Controls.Add(this.button26);
            this.panel1.Controls.Add(this.button27);
            this.panel1.Controls.Add(this.button25);
            this.panel1.Controls.Add(this.button24);
            this.panel1.Controls.Add(this.button15);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label_time);
            this.panel1.Location = new System.Drawing.Point(1, 395);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(901, 41);
            this.panel1.TabIndex = 1;
            this.panel1.Click += new System.EventHandler(this.startmenu);
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(856, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(41, 36);
            this.button1.TabIndex = 1;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Transparent;
            this.panel17.Controls.Add(this.panel21);
            this.panel17.Controls.Add(this.panel20);
            this.panel17.Controls.Add(this.panel19);
            this.panel17.Controls.Add(this.panel14);
            this.panel17.Controls.Add(this.panel7);
            this.panel17.Controls.Add(this.panel3);
            this.panel17.Controls.Add(this.panel10);
            this.panel17.Controls.Add(this.panel4);
            this.panel17.Controls.Add(this.panel5);
            this.panel17.Controls.Add(this.panel6);
            this.panel17.Location = new System.Drawing.Point(753, 5);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(149, 390);
            this.panel17.TabIndex = 10;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.Controls.Add(this.name_notepad);
            this.panel7.Controls.Add(this.NOTEpad);
            this.panel7.Location = new System.Drawing.Point(70, 127);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(61, 55);
            this.panel7.TabIndex = 8;
            // 
            // name_notepad
            // 
            this.name_notepad.AutoSize = true;
            this.name_notepad.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.name_notepad.Location = new System.Drawing.Point(11, 38);
            this.name_notepad.Name = "name_notepad";
            this.name_notepad.Size = new System.Drawing.Size(40, 13);
            this.name_notepad.TabIndex = 6;
            this.name_notepad.Text = "  NOTE";
            // 
            // NOTEpad
            // 
            this.NOTEpad.BackColor = System.Drawing.Color.Transparent;
            this.NOTEpad.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("NOTEpad.BackgroundImage")));
            this.NOTEpad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.NOTEpad.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.NOTEpad.FlatAppearance.BorderSize = 0;
            this.NOTEpad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NOTEpad.Location = new System.Drawing.Point(7, 3);
            this.NOTEpad.Name = "NOTEpad";
            this.NOTEpad.Size = new System.Drawing.Size(48, 35);
            this.NOTEpad.TabIndex = 3;
            this.NOTEpad.UseVisualStyleBackColor = false;
            this.NOTEpad.Click += new System.EventHandler(this.NOTEpad_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.chrome);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(61, 55);
            this.panel3.TabIndex = 5;
            this.panel3.Click += new System.EventHandler(this.gid_);
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // chrome
            // 
            this.chrome.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chrome.BackgroundImage")));
            this.chrome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chrome.FlatAppearance.BorderSize = 0;
            this.chrome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chrome.Location = new System.Drawing.Point(14, 3);
            this.chrome.Name = "chrome";
            this.chrome.Size = new System.Drawing.Size(29, 36);
            this.chrome.TabIndex = 2;
            this.chrome.UseVisualStyleBackColor = true;
            this.chrome.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(11, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Chrome";
            this.label1.Click += new System.EventHandler(this.ChromeButton_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Transparent;
            this.panel10.Controls.Add(this.label7);
            this.panel10.Controls.Add(this.button4);
            this.panel10.Location = new System.Drawing.Point(3, 127);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(61, 55);
            this.panel10.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(-1, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "micro_edge";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(7, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(48, 35);
            this.button4.TabIndex = 3;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.button5);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Location = new System.Drawing.Point(3, 66);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(61, 55);
            this.panel4.TabIndex = 6;
            // 
            // button5
            // 
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(14, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(36, 37);
            this.button5.TabIndex = 10;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(5, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "calculater";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Location = new System.Drawing.Point(70, 66);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(61, 55);
            this.panel5.TabIndex = 7;
            // 
            // button3
            // 
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(14, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(36, 37);
            this.button3.TabIndex = 10;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(3, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "المحدوفات";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.Controls.Add(this.button2);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Location = new System.Drawing.Point(70, 6);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(61, 55);
            this.panel6.TabIndex = 7;
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(14, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(36, 37);
            this.button2.TabIndex = 9;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(11, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "     PC";
            // 
            // power
            // 
            this.power.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("power.BackgroundImage")));
            this.power.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.power.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.power.Location = new System.Drawing.Point(325, 323);
            this.power.Name = "power";
            this.power.Size = new System.Drawing.Size(75, 36);
            this.power.TabIndex = 14;
            this.power.UseVisualStyleBackColor = true;
            this.power.Click += new System.EventHandler(this.power_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel15.Controls.Add(this.Log_out);
            this.panel15.Controls.Add(this.Sleep);
            this.panel15.Controls.Add(this.Rstart);
            this.panel15.Controls.Add(this.P_OFF);
            this.panel15.Location = new System.Drawing.Point(205, 157);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(192, 168);
            this.panel15.TabIndex = 15;
            this.panel15.Visible = false;
            // 
            // Log_out
            // 
            this.Log_out.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Log_out.BackgroundImage")));
            this.Log_out.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Log_out.FlatAppearance.BorderSize = 0;
            this.Log_out.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Log_out.Location = new System.Drawing.Point(120, 70);
            this.Log_out.Name = "Log_out";
            this.Log_out.Size = new System.Drawing.Size(53, 36);
            this.Log_out.TabIndex = 13;
            this.Log_out.UseVisualStyleBackColor = true;
            this.Log_out.Click += new System.EventHandler(this.Log_out_Click);
            // 
            // Sleep
            // 
            this.Sleep.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Sleep.BackgroundImage")));
            this.Sleep.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Sleep.FlatAppearance.BorderSize = 0;
            this.Sleep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sleep.Location = new System.Drawing.Point(120, 7);
            this.Sleep.Name = "Sleep";
            this.Sleep.Size = new System.Drawing.Size(56, 38);
            this.Sleep.TabIndex = 12;
            this.Sleep.UseVisualStyleBackColor = true;
            this.Sleep.Click += new System.EventHandler(this.Sleep_Click);
            // 
            // Rstart
            // 
            this.Rstart.BackColor = System.Drawing.Color.Transparent;
            this.Rstart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Rstart.BackgroundImage")));
            this.Rstart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Rstart.FlatAppearance.BorderSize = 0;
            this.Rstart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Rstart.Location = new System.Drawing.Point(14, 70);
            this.Rstart.Name = "Rstart";
            this.Rstart.Size = new System.Drawing.Size(55, 36);
            this.Rstart.TabIndex = 10;
            this.Rstart.UseVisualStyleBackColor = false;
            this.Rstart.Click += new System.EventHandler(this.Rstart_Click);
            // 
            // P_OFF
            // 
            this.P_OFF.BackColor = System.Drawing.Color.Transparent;
            this.P_OFF.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P_OFF.BackgroundImage")));
            this.P_OFF.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.P_OFF.FlatAppearance.BorderSize = 0;
            this.P_OFF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P_OFF.Location = new System.Drawing.Point(14, 7);
            this.P_OFF.Name = "P_OFF";
            this.P_OFF.Size = new System.Drawing.Size(55, 38);
            this.P_OFF.TabIndex = 11;
            this.P_OFF.UseVisualStyleBackColor = false;
            this.P_OFF.Click += new System.EventHandler(this.P_OFF_Click);
            // 
            // button11
            // 
            this.button11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button11.BackgroundImage")));
            this.button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(3, 323);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 36);
            this.button11.TabIndex = 16;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel16.Controls.Add(this.label12);
            this.panel16.Controls.Add(this.label13);
            this.panel16.Controls.Add(this.label14);
            this.panel16.Controls.Add(this.label15);
            this.panel16.Location = new System.Drawing.Point(3, 157);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(192, 168);
            this.panel16.TabIndex = 17;
            this.panel16.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "label12";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 47);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "label13";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 70);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "label14";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 102);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "label15";
            // 
            // panel2
            // 
            this.panel2.AccessibleDescription = "";
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.panel22);
            this.panel2.Controls.Add(this.panel23);
            this.panel2.Controls.Add(this.panel24);
            this.panel2.Controls.Add(this.panel25);
            this.panel2.Controls.Add(this.panel13);
            this.panel2.Controls.Add(this.panel12);
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel11);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel18);
            this.panel2.Controls.Add(this.panel16);
            this.panel2.Controls.Add(this.button11);
            this.panel2.Controls.Add(this.panel15);
            this.panel2.Controls.Add(this.power);
            this.panel2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.panel2.Location = new System.Drawing.Point(499, 30);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(403, 362);
            this.panel2.TabIndex = 4;
            this.panel2.Visible = false;
            this.panel2.TabStopChanged += new System.EventHandler(this.button1_Click);
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Transparent;
            this.panel13.Controls.Add(this.button10);
            this.panel13.Controls.Add(this.label10);
            this.panel13.Location = new System.Drawing.Point(205, 68);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(61, 55);
            this.panel13.TabIndex = 22;
            // 
            // button10
            // 
            this.button10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button10.BackgroundImage")));
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(14, 3);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(36, 37);
            this.button10.TabIndex = 10;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(5, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "calculater";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Transparent;
            this.panel12.Controls.Add(this.button9);
            this.panel12.Controls.Add(this.label9);
            this.panel12.Location = new System.Drawing.Point(272, 7);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(61, 55);
            this.panel12.TabIndex = 21;
            // 
            // button9
            // 
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(14, 0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(36, 37);
            this.button9.TabIndex = 10;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(3, 40);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "المحدوفات";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Transparent;
            this.panel9.Controls.Add(this.label6);
            this.panel9.Controls.Add(this.button6);
            this.panel9.Location = new System.Drawing.Point(205, 7);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(61, 55);
            this.panel9.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(11, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "  NOTE";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(7, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(48, 35);
            this.button6.TabIndex = 3;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Transparent;
            this.panel11.Controls.Add(this.button8);
            this.panel11.Controls.Add(this.label8);
            this.panel11.Location = new System.Drawing.Point(339, 7);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(61, 55);
            this.panel11.TabIndex = 19;
            // 
            // button8
            // 
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(14, 0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(36, 37);
            this.button8.TabIndex = 9;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(11, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "     PC";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.Controls.Add(this.label5);
            this.panel8.Controls.Add(this.button7);
            this.panel8.Location = new System.Drawing.Point(339, 68);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(61, 55);
            this.panel8.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(11, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "winrar";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(7, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(48, 35);
            this.button7.TabIndex = 3;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Transparent;
            this.panel18.Controls.Add(this.button12);
            this.panel18.Controls.Add(this.label16);
            this.panel18.Location = new System.Drawing.Point(272, 68);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(61, 55);
            this.panel18.TabIndex = 7;
            // 
            // button12
            // 
            this.button12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button12.BackgroundImage")));
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(14, 3);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(29, 36);
            this.button12.TabIndex = 2;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(11, 38);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 13);
            this.label16.TabIndex = 6;
            this.label16.Text = "Chrome";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Transparent;
            this.button13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button13.BackgroundImage")));
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(752, 2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(41, 36);
            this.button13.TabIndex = 2;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Transparent;
            this.button14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button14.BackgroundImage")));
            this.button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(699, 2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(41, 36);
            this.button14.TabIndex = 3;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Transparent;
            this.button15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button15.BackgroundImage")));
            this.button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Location = new System.Drawing.Point(801, 6);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(39, 28);
            this.button15.TabIndex = 11;
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Transparent;
            this.panel14.Controls.Add(this.label11);
            this.panel14.Controls.Add(this.button16);
            this.panel14.Location = new System.Drawing.Point(70, 188);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(61, 55);
            this.panel14.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(11, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = " word";
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Transparent;
            this.button16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button16.BackgroundImage")));
            this.button16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button16.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(7, 3);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(48, 35);
            this.button16.TabIndex = 3;
            this.button16.UseVisualStyleBackColor = false;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.Transparent;
            this.panel19.Controls.Add(this.label17);
            this.panel19.Controls.Add(this.button17);
            this.panel19.Location = new System.Drawing.Point(3, 188);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(61, 55);
            this.panel19.TabIndex = 11;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label17.Location = new System.Drawing.Point(11, 38);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(32, 13);
            this.label17.TabIndex = 6;
            this.label17.Text = "excel";
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Transparent;
            this.button17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button17.BackgroundImage")));
            this.button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button17.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button17.FlatAppearance.BorderSize = 0;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(7, 3);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(48, 35);
            this.button17.TabIndex = 3;
            this.button17.UseVisualStyleBackColor = false;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Transparent;
            this.panel20.Controls.Add(this.label18);
            this.panel20.Controls.Add(this.button18);
            this.panel20.Location = new System.Drawing.Point(3, 249);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(61, 55);
            this.panel20.TabIndex = 9;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label18.Location = new System.Drawing.Point(11, 38);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 13);
            this.label18.TabIndex = 6;
            this.label18.Text = "winrar";
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Transparent;
            this.button18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button18.BackgroundImage")));
            this.button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button18.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button18.FlatAppearance.BorderSize = 0;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(7, 3);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(48, 35);
            this.button18.TabIndex = 3;
            this.button18.UseVisualStyleBackColor = false;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.Transparent;
            this.panel21.Controls.Add(this.label19);
            this.panel21.Controls.Add(this.button19);
            this.panel21.Location = new System.Drawing.Point(70, 249);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(61, 55);
            this.panel21.TabIndex = 11;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label19.Location = new System.Drawing.Point(11, 38);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 13);
            this.label19.TabIndex = 6;
            this.label19.Text = "power...";
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Transparent;
            this.button19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button19.BackgroundImage")));
            this.button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button19.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button19.FlatAppearance.BorderSize = 0;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Location = new System.Drawing.Point(7, 3);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(48, 35);
            this.button19.TabIndex = 3;
            this.button19.UseVisualStyleBackColor = false;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.Transparent;
            this.panel22.Controls.Add(this.label20);
            this.panel22.Controls.Add(this.button20);
            this.panel22.Location = new System.Drawing.Point(143, 71);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(61, 55);
            this.panel22.TabIndex = 25;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label20.Location = new System.Drawing.Point(11, 38);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 13);
            this.label20.TabIndex = 6;
            this.label20.Text = "power...";
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Transparent;
            this.button20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button20.BackgroundImage")));
            this.button20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button20.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button20.FlatAppearance.BorderSize = 0;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(7, 3);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(48, 35);
            this.button20.TabIndex = 3;
            this.button20.UseVisualStyleBackColor = false;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.Transparent;
            this.panel23.Controls.Add(this.label21);
            this.panel23.Controls.Add(this.button21);
            this.panel23.Location = new System.Drawing.Point(71, 71);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(61, 55);
            this.panel23.TabIndex = 23;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label21.Location = new System.Drawing.Point(11, 38);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(37, 13);
            this.label21.TabIndex = 6;
            this.label21.Text = "winrar";
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Transparent;
            this.button21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button21.BackgroundImage")));
            this.button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button21.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button21.FlatAppearance.BorderSize = 0;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(7, 3);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(48, 35);
            this.button21.TabIndex = 3;
            this.button21.UseVisualStyleBackColor = false;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.Transparent;
            this.panel24.Controls.Add(this.label22);
            this.panel24.Controls.Add(this.button22);
            this.panel24.Location = new System.Drawing.Point(71, 10);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(61, 55);
            this.panel24.TabIndex = 26;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label22.Location = new System.Drawing.Point(11, 38);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(32, 13);
            this.label22.TabIndex = 6;
            this.label22.Text = "excel";
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Transparent;
            this.button22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button22.BackgroundImage")));
            this.button22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button22.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button22.FlatAppearance.BorderSize = 0;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(7, 3);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(48, 35);
            this.button22.TabIndex = 3;
            this.button22.UseVisualStyleBackColor = false;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.Transparent;
            this.panel25.Controls.Add(this.label23);
            this.panel25.Controls.Add(this.button23);
            this.panel25.Location = new System.Drawing.Point(138, 7);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(61, 55);
            this.panel25.TabIndex = 24;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label23.Location = new System.Drawing.Point(11, 38);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(34, 13);
            this.label23.TabIndex = 6;
            this.label23.Text = " word";
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Transparent;
            this.button23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button23.BackgroundImage")));
            this.button23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button23.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button23.FlatAppearance.BorderSize = 0;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(7, 3);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(48, 35);
            this.button23.TabIndex = 3;
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Transparent;
            this.button24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button24.BackgroundImage")));
            this.button24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button24.FlatAppearance.BorderSize = 0;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Location = new System.Drawing.Point(5, 4);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(37, 33);
            this.button24.TabIndex = 12;
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Transparent;
            this.button25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button25.BackgroundImage")));
            this.button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button25.FlatAppearance.BorderSize = 0;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(195, 9);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(25, 23);
            this.button25.TabIndex = 13;
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Transparent;
            this.button26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button26.BackgroundImage")));
            this.button26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button26.FlatAppearance.BorderSize = 0;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(264, 6);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(28, 29);
            this.button26.TabIndex = 11;
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Transparent;
            this.button27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button27.BackgroundImage")));
            this.button27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button27.FlatAppearance.BorderSize = 0;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(226, 7);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(32, 27);
            this.button27.TabIndex = 12;
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Transparent;
            this.button28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button28.BackgroundImage")));
            this.button28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button28.FlatAppearance.BorderSize = 0;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Location = new System.Drawing.Point(298, 10);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(21, 20);
            this.button28.TabIndex = 12;
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button29.BackgroundImage")));
            this.button29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button29.FlatAppearance.BorderSize = 0;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Location = new System.Drawing.Point(655, 2);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(29, 36);
            this.button29.TabIndex = 11;
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(903, 436);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "windows";
            this.Load += new System.EventHandler(this.startmenu);
            this.Click += new System.EventHandler(this.startmenu);
            this.DoubleClick += new System.EventHandler(this.gid);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_time;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label name_notepad;
        private System.Windows.Forms.Button NOTEpad;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button chrome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Button Log_out;
        private System.Windows.Forms.Button Sleep;
        private System.Windows.Forms.Button Rstart;
        private System.Windows.Forms.Button P_OFF;
        private System.Windows.Forms.Button power;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button29;
    }
}

