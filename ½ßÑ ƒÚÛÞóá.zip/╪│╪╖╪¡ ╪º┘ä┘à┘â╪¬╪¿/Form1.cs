﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;


namespace سطح_المكتب
{
    public partial class Form1 : Form
    {
        [DllImport("user32")]
        public static extern bool ExitWindowsEx(uint uFlags, uint dwReason);
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label_time.Text = DateTime.Now.ToString();
        }
        private void startmenu(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel15.Visible = false;
            panel16.Visible = false;
            panel17.Visible = true;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

       

        private void button1_Click(object sender, EventArgs e)
        {

            panel2.Visible =!panel2.Visible;
            panel17.Visible= !panel2.Visible;


        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void NOTEpad_Click(object sender, EventArgs e)
        {
            Process.Start(Convert.ToString("notepad"));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Process.Start(Convert.ToString("notepad"));
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void gid(object sender,EventArgs e)
        {
            
        }
        private void gid_(object sender, EventArgs e)
        {
           
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            
        }
        

        private void ChromeButton_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            button29.Visible = true;
            Process.Start("chrome");
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Process.Start("chrome");
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            Process.Start("D:\\");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Process.Start(Convert.ToString("notepad"));
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Process.Start("calc");
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Process.Start("maicrosoftedge");
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void power_Click(object sender, EventArgs e)
        {
            panel15.Visible = !(panel15.Visible);
            panel16.Visible = false;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            panel16.Visible = !(panel16.Visible);
            panel15.Visible = false;
            label12.Text = System.Environment.MachineName;
            label13.Text = System.Environment.UserName;
            label14.Text = System.Environment.CurrentDirectory;
            label15.Text = System.Environment.Is64BitOperatingSystem.ToString();
        }

        private void P_OFF_Click(object sender, EventArgs e)
        {
            Process.Start("shutdown", "/s /t 1");
        }

        private void Rstart_Click(object sender, EventArgs e)
        {
            Process.Start("shutdown", "/r /t 0");
        }

        private void Log_out_Click(object sender, EventArgs e)
        {
            ExitWindowsEx(0, 0);
        }

        private void Sleep_Click(object sender, EventArgs e)
        {
            Application.SetSuspendState(PowerState.Suspend, true, true);
        }

        private void panel3_DoubleClick(object sender, EventArgs e)
        {
            Process.Start("chrome");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Process.Start("D:\\");
        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            Process.Start("chrome");
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            Process.Start(Convert.ToString("notepad"));
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Process.Start("maicrosoftedge");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Process.Start("calc");
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {

        }
    }
}
